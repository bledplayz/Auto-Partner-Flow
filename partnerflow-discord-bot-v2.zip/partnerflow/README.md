# 🤝 PartnerFlow — Discord Partnership Bot

A Python Discord bot for **mutual partnership ad exchange** between opt-in Discord servers. Built with `discord.py` and SQLite, with slash commands and an interactive setup panel. No paid API or external database needed.

> **Important:** This is an original starter implementation, not the official Auto Partner bot. The current version matches partners on demand with `/find_partner`; it does **not** automatically post on a timer. It never sends `@everyone`, `@here`, or role pings. Ping preferences are stored but requests for actual pings are not matched in this version. Server admins should only use it in channels designated for partnerships.

## ✨ Features

- `/setup` — interactive setup panel with ad-writing modal and settings display
- `/set_ad` — write or paste your advertisement
- `/import_ad` — select a channel and provide a message ID to import an advertisement
- `/set_partner_channel` — select the channel that receives partner ads
- `/requirements` — configure minimum member count and ping preference
- `/partner_toggle` — opt in/out of matching
- `/partner_status` — review configuration and completed match count
- `/find_partner` — exchange ads with a mutually compatible, unmatched server
- Persistent SQLite storage; prevents duplicate pairings; escape mentions in ads
- Restricted configuration commands to admins with Manage Server permission

### Requirements / ping rules

Suggested defaults for server size:

| Members | Suggested ping setting |
| --- | --- |
| 1–200 | No ping |
| 201–500 | Optional (admin chooses) |
| 501–1,000 | Optional (admin chooses) |
| 1,001+ | Optional (admin chooses) |

**These ranges are guidance, not automatically enforced tiers.** Admins choose the minimum member count and ping preference with `/requirements`. The current matching engine supports `none` and `optional` policies only, and always posts without pings. `role` and `everyone` preferences are recorded but excluded from matching until an opt-in, consent-based ping system is built.

## 1. Create a Discord bot

1. Visit [Discord Developer Portal](https://discord.com/developers/applications).
2. Click **New Application**, name it, and create it.
3. Open **Bot** and select **Reset Token** (or copy the available token). **Never share your token or put it in GitHub.**
4. Under **Installation** / OAuth2, configure Guild Install with `bot` and `applications.commands` scopes.
5. Grant permissions **View Channels**, **Send Messages**, **Embed Links**, and **Read Message History**. You can use the installation link to invite the bot.
6. You do **not** need Message Content intent for this bot. Member counts come from guild metadata.

## 2. Upload to GitHub

1. Create a new repository at [github.com/new](https://github.com/new).
2. Upload `main.py`, `requirements.txt`, `.env.example`, `.gitignore`, and `README.md`.
3. **Never upload `.env`, `*.sqlite3`, or your bot token.**
4. Commit your files.

## 3. Test locally (optional)

Requires Python 3.10+.

```bash
python -m pip install -r requirements.txt
```

Linux/macOS:

```bash
export BOT_TOKEN='YOUR_PRIVATE_TOKEN'
python main.py
```

Windows PowerShell:

```powershell
$env:BOT_TOKEN='YOUR_PRIVATE_TOKEN'
python main.py
```

`.env.example` is a template only; the script reads actual environment variables. It does not automatically load `.env` files.

## 4. Host on Bot-Hosting.net

1. Visit [bot-hosting.net](https://bot-hosting.net/) and create an account.
2. Create a **Python** bot instance if that runtime is available on your plan. Hosting interfaces and pricing can change.
3. Upload your repository files using the panel's file manager or Git integration, if available.
4. Set the startup file/command to `main.py` or `python main.py` as required by the host.
5. Install dependencies from `requirements.txt` (often via the panel's Python packages/dependencies feature).
6. In the host's **environment variables / startup variables / secrets** section, create `BOT_TOKEN` with your private token. If the panel does not support private variables, use a private configuration method supported by the host; **never commit the token**.
7. Start the bot and inspect console logs for `Logged in as` and `Synced ... commands`.
8. Keep the SQLite file on persistent storage. If your host resets the filesystem between restarts, configuration and matches will be lost unless you configure persistent storage or an external database.

## 5. Configure your server

1. Invite the bot to **at least two participating servers**.
2. In each server, run `/set_partner_channel` and select a text channel.
3. Run `/set_ad` to write an advertisement, **or** `/import_ad` with a channel and message ID. To copy a message ID, enable Discord Developer Mode in Advanced settings, then right-click/long-press the message and select Copy Message ID.
4. Run `/requirements` (e.g., minimum members `1`, ping policy `No ping`).
5. Run `/partner_toggle enabled:true` in both servers.
6. Run `/find_partner` to exchange ads. Both servers must meet each other's minimum member count and support no-ping ads.

## ⚠️ Known limitations

- This version matches **on command**, not in a background auto-post loop.
- No support for ping delivery, partnership tickets, staff approvals, web dashboard, automatic sync of edited source ads, or timed matchmaking.
- A failure while posting the second advertisement can leave one advertisement posted; the command warns admins to remove it manually.
- SQLite is suitable for a single bot process. Avoid running multiple replicas against the same SQLite file.
- Discord global slash command propagation may take some time.
- Respect Discord's policies and each server's consent; do not use this to spam or send unsolicited DMs.

## 🔐 Security

All outbound ads disable mentions and escape user-entered mention syntax. The bot does not require Administrator permission. Never share the bot token; reset it in the Developer Portal if exposed.

## 📄 License

MIT — see `LICENSE`.
